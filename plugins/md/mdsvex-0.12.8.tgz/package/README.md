# @cheungray/mdsvex

Fork of [pngwn/mdsvex](https://github.com/pngwn/MDsveX) v0.12.7, fully adapted for **Svelte 5** production use.

## What's New (v0.12.8)

### Svelte 5 Runes Deep Adaptation

- **`$props()` pattern**: Frontmatter keys are now exposed via `const { title, date } = $props();` in the instance script, enabling Svelte 5's reactive prop system.
- **Layout children snippet**: Layout wrapping uses Svelte 5's children snippet pattern — content between `<Layout_MDSVEX_DEFAULT>` tags is automatically available as a `children` snippet prop.
- **Event handler modernization**: Auto-converts deprecated Svelte 4 `on:click` directive syntax to Svelte 5 native `onclick` event handler syntax.
- **Snippet type declarations**: `globals.d.ts` now declares `Snippet` type for children, compatible with Svelte 5's component API.

### Source Map Support

- Full source map generation using VLQ-encoded mappings (version 3 format).
- Enabled by default (`sourceMap: true`).
- Tracks original-to-generated line/column mappings for debugging.

### Vite Plugin + HMR

- New `mdsvexVitePlugin` for native Vite integration.
- Hot Module Replacement (HMR) support for `.svx` and `.md` files.
- Usage: `import { mdsvexVitePlugin } from '@cheungray/mdsvex/vite'`.

### Frontmatter Schema (Zod Integration)

- Optional `schema` option for type-safe frontmatter validation.
- Compatible with Zod schemas (`.parse()` method).
- Added to `defineMDSveXConfig` for seamless integration.

### Shiki Syntax Highlighting

- Built-in Shiki integration with VS Code-compatible themes.
- Auto-fallback to basic highlighting when Shiki is not installed.
- Usage: `highlight: { shiki: { theme: 'github-dark' } }`.

### Type Safety Improvements

- Eliminated `any` types throughout the codebase.
- Added `SvelteParseResult`, `SvelteHtmlChild`, `SvelteScriptNode` types.
- Added `RawNode` type for HAST raw nodes.
- Proper TypeScript declarations for all Svelte 5 AST structures.

## Install

```bash
pnpm add @cheungray/mdsvex
```

Optional peer dependencies:
```bash
pnpm add -D shiki   # for Shiki syntax highlighting
pnpm add -D zod     # for frontmatter schema validation
```

## Usage

### As Svelte Preprocessor

```js
// svelte.config.js
import { mdsvex } from '@cheungray/mdsvex';

export default {
  preprocess: mdsvex({
    extensions: ['.svx', '.md'],
    highlight: { shiki: { theme: 'github-dark' } },
  }),
};
```

### As Vite Plugin (with HMR)

```js
// vite.config.js
import { mdsvexVitePlugin } from '@cheungray/mdsvex/vite';

export default {
  plugins: [mdsvexVitePlugin({
    extensions: ['.svx', '.md'],
  })],
};
```

### Type-Safe Config with Schema

```js
// mdsvex.config.js
import { defineMDSveXConfig } from '@cheungray/mdsvex';
import { z } from 'zod';

export default defineMDSveXConfig({
  extensions: ['.svx', '.md'],
  schema: z.object({
    title: z.string(),
    date: z.coerce.date(),
    tags: z.array(z.string()).optional(),
  }),
  highlight: { shiki: { theme: 'github-dark' } },
  sourceMap: true,
});
```

### Layout (Svelte 5 Snippet Pattern)

```svelte
<!-- Layout.svelte -->
<script>
  let { children, ...metadata } = $props();
</script>

{@render children()}
```

## Svelte 5 Layout Pattern

The generated `.svx` content wraps HTML inside `<Layout_MDSVEX_DEFAULT {...metadata}>` tags. In Svelte 5, content between component tags is automatically available as a `children` snippet prop. The layout component should use:

```svelte
<script>
  let { children, ...metadata } = $props();
</script>

{@render children()}
```

This is the recommended Svelte 5 pattern for content composition.

## Build

```bash
pnpm build   # rollup -c
```

## Test

```bash
pnpm test    # node test/test.js
```

## License

MIT — same as upstream.
