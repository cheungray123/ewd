declare module '*.svx' {
	import type { Component, Snippet } from 'svelte';

	const component: Component<{
		children?: Snippet;
		[key: string]: unknown;
	}>;
	export default component;
	export const metadata: Record<string, unknown>;
}

declare module '*.svelte.md' {
	import type { Component, Snippet } from 'svelte';

	const component: Component<{
		children?: Snippet;
		[key: string]: unknown;
	}>;
	export default component;
	export const metadata: Record<string, unknown>;
}

declare module '*.md' {
	import type { Component, Snippet } from 'svelte';

	const component: Component<{
		children?: Snippet;
		[key: string]: unknown;
	}>;
	export default component;
	export const metadata: Record<string, unknown>;
}
